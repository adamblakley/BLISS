To execute game, make sure BLISS.exe and the BLISS_Data folder are within the same file location.

For optimal use, run BLISS at a resolution of 1920x1080.

A mouse is required to play the game.