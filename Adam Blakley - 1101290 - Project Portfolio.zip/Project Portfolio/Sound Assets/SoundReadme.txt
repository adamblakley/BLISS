Sound Files obtained online from freesound.org.

All sound files are useable through creative commons licensing.

Interface Click: uEffects (2013) Mouse Click[Online] Available From, www.freesound.org/people/ueffects/sounds/180999 [last accessed 20/04/15]
Start Game Sound: Killkhan (2012) Menu Select [Online] Available From, www.freesound.org/people/killkhan/sounds/150222 [last accessed 20/04/15]
In-Game Music: Luckylittleraven (2013) Sweet Clouds[Online] Available From, www.freesound.org/people/luckylittleraven/sounds/202221[last accessed 20/04/15]
Start Screen Music: Frankum (2014) Electronic Music Loop 001[Online] Available From, www.freesound.org/people/frankum/sounds/255585 [last accessed 20/04/15]
Ticking Clock: Spaceemotion (2013) Old Clock[Online] Available From, www.freesound.org/people/spaceemotion/sounds/243020 [last accessed 20/04/15]
Mood Improvement: VincentM400 (2014)Confirm [Online] Available From, www.freesound.org/people/vincentm400/sounds/249615 [last accessed 20/04/15]
Mood Deterioration: VincentM400 (2014) Invalid [Online] Available From, www.freesound.org/people/vincentm400/sounds/249615 [last accessed 20/04/15]
Score Increase: Plasterbrain (2014) Game Start [Online] Available From, www.freesound.org/people/plasterbrain/sounds/243020 [last accessed 20/04/15]
Money Increase: LeMudCrab 2012) Money Pickup [Online] Available From, www.freesound.org/people/lemudcrab/sounds/163415 [last accessed 20/04/15]
Door Sound Effect: Killkhan (2012) Reload[Online] Available From, www.freesound.org/people/killkhan/sounds/150215 [last accessed 20/04/15]
Feat Sound EffectPlasterbrain (2014) Friend Request [Online] Available From, www.freesound.org/people/plasterbrain/sounds/242855 [last accessed 20/04/15]
