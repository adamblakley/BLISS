Videos demonstrate Day 1 and Day 5 ingame from a selectable 8 Days. No sound is availble.

Additionall there is a video of an unused concept prototype. More information on this game can be found within the Development Book and Final Presentation.