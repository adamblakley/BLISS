Included within the Project Portfolio

1x Executable Game File
1x Executable Game File Data
244x Art Assets
1x Game Design Document
1X Development Book
1x Learning Contract
2x Demonstration video
1x Unused Concept Prototype video

All files created by Adam Blakley, 1101290, unless stated otherwise.

Main project artefact is BLISS.exe available within the Executable folder.In order to play BLISS.exe, please make sure the BLISS.data folder is contained within the same location. For the best experience, please play at a resolution of 1920x1080 and fullscreen.